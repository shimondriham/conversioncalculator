import './App.css';
import AppExchange from './comps/appExchange';

function App() {
  return (
    <div className="container">
  <AppExchange/>
    </div>
  );
}

export default App;
