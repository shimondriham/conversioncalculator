import {createContext} from 'react';
 
export const amountcontext = createContext(null);