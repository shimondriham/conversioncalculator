import {createContext} from 'react';
 
export const abcontext = createContext(null);