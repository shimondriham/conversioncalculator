import {createContext} from 'react';
 
export const totalcontext = createContext(null);