import React from 'react';
import { context } from '../context/context'

function ScoreEX(props){
    // let {ar,setAr} = useContext(context)
    return(
        <div>ScoreEX work</div> 
    )
}

export default ScoreEX