import React, { useState } from 'react';
import InputEX from './inputEX';
import ScoreEX from './scoreEX';
import { context } from '../context/context'

function AppExchange(props) {
    let [total,setTotal] = useState(1);
    let [amount,setAmount] = useState(1);
    return (
        <context.Provider value={{total,setTotal},{amount,setAmount}}>
            <React.Fragment >
                <InputEX />
                <ScoreEX />
            </React.Fragment>
        </context.Provider>


    )
}

export default AppExchange